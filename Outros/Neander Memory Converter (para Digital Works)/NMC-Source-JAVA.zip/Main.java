/*
 * Decompiled with CFR 0_118.
 * 
 * Could not load the following classes:
 *  nmc.Importador
 */
package nmc;

import nmc.Importador;

public class Main {
    public static void main(String[] args) {
        Importador imp = new Importador();
        imp.abreArq();
    }
}
